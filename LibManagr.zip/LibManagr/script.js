// Sample data to simulate a book collection
let books = [];

// Function to add a book
document.getElementById('add-book-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const bookType = document.getElementById('book-type').value;
    const title = document.getElementById('book-title').value;
    const author = document.getElementById('book-author').value;
    const serialNo = document.getElementById('book-serial').value;

    if (!title || !author || !serialNo) {
        document.getElementById('add-book-error').innerText = "All fields are required.";
        return;
    }

    books.push({ type: bookType, title, author, serialNo });
    document.getElementById('add-book-error').innerText = "Book added successfully!";
    document.getElementById('add-book-form').reset();
});

// Function to issue a book
document.getElementById('issue-book-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('issue-book-title').value;
    const authorField = document.getElementById('issue-book-author');
    const issueDate = new Date(document.getElementById('issue-date').value);
    const returnDate = new Date(document.getElementById('return-date').value);

    // Check if the book exists
    const book = books.find(b => b.title === title);
    if (!book) {
        document.getElementById('issue-book-error').innerText = "Book not found.";
        return;
    }

    // Populate author field
    authorField.value = book.author;

    // Validate dates
    const today = new Date();
    if (issueDate < today) {
        document.getElementById('issue-book-error').innerText = "Issue date cannot be in the past.";
        return;
    }

    if (returnDate < issueDate || returnDate > new Date(issueDate.setDate(issueDate.getDate() + 15))) {
        document.getElementById('issue-book-error').innerText = "Return date must be within 15 days.";
        return;
    }

    document.getElementById('issue-book-error').innerText = "Book issued successfully!";
    document.getElementById('issue-book-form').reset();
});

// Function to return a book
document.getElementById('return-book-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('return-book-title').value;
    const authorField = document.getElementById('return-book-author');
    const serialNo = document.getElementById('return-book-serial').value;

    // Check if the book exists
    const book = books.find(b => b.title === title);
    if (!book) {
        document.getElementById('return-book-error').innerText = "Book not found.";
        return;
    }

    // Populate author field
    authorField.value = book.author;

    // Validate serial number
    if (!serialNo) {
        document.getElementById('return-book-error').innerText = "Serial No is required.";
        return;
    }

    document.getElementById('return-book-error').innerText = "Book returned successfully!";
    document.getElementById('return-book-form').reset();
});

// Function to add membership
document.getElementById('membership-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const memberName = document.getElementById('member-name').value;
    const membershipDuration = document.getElementById('membership-duration').value;

    if (!memberName) {
        document.getElementById('membership-error').innerText = "Member name is required.";
        return;
    }

    document.getElementById('membership-error').innerText = "Membership added successfully!";
    document.getElementById('membership-form').reset();
});